import React, { useState, useEffect } from 'react';
import { Dashboard } from './components/Dashboard';
import { JobsManager } from './components/JobsManager';
import { ClientsManager } from './components/ClientsManager';
import { FinancialTools } from './components/FinancialTools';
import { DataManager } from './components/DataManager';
import { Settings } from './components/Settings';
import { Navigation } from './components/Navigation';
import { ToastContainer } from './components/Toast';
import { useLocalStorage } from './hooks/useLocalStorage';
import { Job, Client } from './types';
import { initializeDemoData } from './utils/demoData';

function App() {
  const [currentView, setCurrentView] = useState('dashboard');
  const [darkMode, setDarkMode] = useLocalStorage('sfe_dark_mode', false);
  const [jobs, setJobs] = useLocalStorage<Job[]>('sfe_jobs', []);
  const [clients, setClients] = useLocalStorage<Client[]>('sfe_clients', []);

  useEffect(() => {
    // Initialize demo data if no data exists
    if (jobs.length === 0 && clients.length === 0) {
      const demoData = initializeDemoData();
      setJobs(demoData.jobs);
      setClients(demoData.clients);
    }
  }, [jobs.length, clients.length, setJobs, setClients]);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const renderCurrentView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard jobs={jobs} clients={clients} />;
      case 'jobs':
        return <JobsManager jobs={jobs} setJobs={setJobs} clients={clients} />;
      case 'clients':
        return <ClientsManager clients={clients} setClients={setClients} jobs={jobs} />;
      case 'financial':
        return <FinancialTools jobs={jobs} />;
      case 'data':
        return <DataManager jobs={jobs} setJobs={setJobs} clients={clients} setClients={setClients} />;
      case 'settings':
        return <Settings darkMode={darkMode} setDarkMode={setDarkMode} />;
      default:
        return <Dashboard jobs={jobs} clients={clients} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      {/* Mobile Header */}
      <header className="md:hidden fixed top-0 left-0 right-0 bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 z-40 pt-safe">
        <div className="flex items-center justify-center py-2 px-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg overflow-hidden flex items-center justify-center bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600">
              <img 
                src="/Logo.png" 
                alt="Secure Flow Engineering" 
                className="w-8 h-8 object-contain"
              />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">Secure Flow</h1>
            </div>
          </div>
        </div>
      </header>
      
      {/* Mobile Header */}
      <header className="md:hidden fixed top-0 left-0 right-0 bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 z-40 pt-safe">
        <div className="flex items-center justify-center py-2 px-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg overflow-hidden flex items-center justify-center bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600">
              <img 
                src="/Logo.png" 
                alt="Secure Flow Engineering" 
                className="w-8 h-8 object-contain"
              />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">Secure Flow</h1>
            </div>
          </div>
        </div>
      </header>
      
      <Navigation 
        currentView={currentView} 
        setCurrentView={setCurrentView}
        darkMode={darkMode}
      />
      
      <main className="pt-16 pb-16 md:pb-0 md:ml-64 md:pt-0">
        {renderCurrentView()}
      </main>
      
      <ToastContainer />
    </div>
  );
}

export default App;