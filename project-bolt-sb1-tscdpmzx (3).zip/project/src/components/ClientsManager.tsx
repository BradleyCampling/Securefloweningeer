import React, { useState } from 'react';
import { Client, Job } from '../types';
import { 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  Users,
  Phone,
  Mail,
  MapPin,
  Building
} from 'lucide-react';
import { Modal } from './Modal';
import { ClientForm } from './ClientForm';
import { showToast } from './Toast';

interface ClientsManagerProps {
  clients: Client[];
  setClients: (clients: Client[]) => void;
  jobs: Job[];
}

export function ClientsManager({ clients, setClients, jobs }: ClientsManagerProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);

  const filteredClients = clients.filter((client) => {
    return (
      client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client.company?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const handleAddClient = () => {
    setSelectedClient(null);
    setIsFormOpen(true);
  };

  const handleEditClient = (client: Client) => {
    setSelectedClient(client);
    setIsFormOpen(true);
  };

  const handleDeleteClient = (clientId: string) => {
    const clientJobs = jobs.filter(job => job.clientId === clientId);
    if (clientJobs.length > 0) {
      alert(`Cannot delete client. They have ${clientJobs.length} associated job(s).`);
      return;
    }

    if (confirm('Are you sure you want to delete this client?')) {
      setClients(clients.filter(client => client.id !== clientId));
      showToast('Client deleted successfully', 'success');
    }
  };

  const handleSaveClient = (clientData: Omit<Client, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (selectedClient) {
      // Edit existing client
      setClients(clients.map(client => 
        client.id === selectedClient.id 
          ? { ...clientData, id: selectedClient.id, createdAt: selectedClient.createdAt, updatedAt: new Date().toISOString() }
          : client
      ));
      showToast('Client updated successfully', 'success');
    } else {
      // Add new client
      const newClient: Client = {
        ...clientData,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      setClients([...clients, newClient]);
      showToast('Client created successfully', 'success');
    }
    setIsFormOpen(false);
  };

  const getClientStats = (clientId: string) => {
    const clientJobs = jobs.filter(job => job.clientId === clientId);
    const completedJobs = clientJobs.filter(job => job.status === 'completed');
    const totalEarned = completedJobs.filter(job => job.isPaid).reduce((sum, job) => sum + job.amount, 0);
    const totalUnpaid = completedJobs.filter(job => !job.isPaid).reduce((sum, job) => sum + job.amount, 0);

    return {
      totalJobs: clientJobs.length,
      completedJobs: completedJobs.length,
      activeJobs: clientJobs.filter(job => job.status === 'active').length,
      totalEarned,
      totalUnpaid,
    };
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Clients Manager</h1>
          <p className="mt-1 text-gray-500 dark:text-gray-400">
            Manage your client relationships and contact information
          </p>
        </div>
        <button
          onClick={handleAddClient}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Add Client</span>
        </button>
      </div>

      {/* Search */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search clients by name, email, or company..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Clients Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredClients.map((client) => {
          const stats = getClientStats(client.id);
          
          return (
            <div
              key={client.id}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow duration-200"
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">
                      {client.name}
                    </h3>
                    {client.company && (
                      <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-2">
                        <Building className="w-4 h-4 mr-1" />
                        {client.company}
                      </div>
                    )}
                  </div>
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-emerald-600 rounded-full flex items-center justify-center">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  {client.email && (
                    <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
                      <Mail className="w-4 h-4 mr-2 text-gray-400" />
                      <a 
                        href={`mailto:${client.email}`}
                        className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                      >
                        {client.email}
                      </a>
                    </div>
                  )}
                  {client.phone && (
                    <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
                      <Phone className="w-4 h-4 mr-2 text-gray-400" />
                      <a 
                        href={`tel:${client.phone}`}
                        className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                      >
                        {client.phone}
                      </a>
                    </div>
                  )}
                  {client.address && (
                    <div className="flex items-start text-sm text-gray-600 dark:text-gray-300">
                      <MapPin className="w-4 h-4 mr-2 mt-0.5 text-gray-400 flex-shrink-0" />
                      <span className="line-clamp-2">{client.address}</span>
                    </div>
                  )}
                </div>

                {/* Client Stats */}
                <div className="grid grid-cols-2 gap-4 mb-4 p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                  <div className="text-center">
                    <div className="text-lg font-semibold text-gray-900 dark:text-white">
                      {stats.totalJobs}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      Total Jobs
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-semibold text-gray-900 dark:text-white">
                      {stats.activeJobs}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      Active
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-semibold text-green-600 dark:text-green-400">
                      £{stats.totalEarned.toLocaleString()}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      Earned
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-semibold text-orange-600 dark:text-orange-400">
                      £{stats.totalUnpaid.toLocaleString()}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      Unpaid
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleEditClient(client)}
                      className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteClient(client.id)}
                      className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <span className="text-xs text-gray-400 dark:text-gray-500">
                    Added {new Date(client.createdAt).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredClients.length === 0 && (
        <div className="text-center py-12">
          <div className="w-12 h-12 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center mx-auto mb-4">
            <Users className="w-6 h-6 text-gray-400 dark:text-gray-500" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            No clients found
          </h3>
          <p className="text-gray-500 dark:text-gray-400 mb-6">
            {searchTerm
              ? "Try adjusting your search term"
              : "Get started by adding your first client"
            }
          </p>
          {!searchTerm && (
            <button
              onClick={handleAddClient}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg flex items-center space-x-2 mx-auto transition-colors"
            >
              <Plus className="w-5 h-5" />
              <span>Add First Client</span>
            </button>
          )}
        </div>
      )}

      {/* Client Form Modal */}
      <Modal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        title={selectedClient ? 'Edit Client' : 'Create New Client'}
      >
        <ClientForm
          client={selectedClient}
          onSave={handleSaveClient}
          onCancel={() => setIsFormOpen(false)}
        />
      </Modal>
    </div>
  );
}