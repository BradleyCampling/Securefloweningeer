import React from 'react';
import { 
  Sun, 
  Moon, 
  Settings as SettingsIcon,
  Bell,
  Shield,
  Database,
  Palette,
  Globe,
  Info
} from 'lucide-react';

interface SettingsProps {
  darkMode: boolean;
  setDarkMode: (darkMode: boolean) => void;
}

export function Settings({ darkMode, setDarkMode }: SettingsProps) {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Settings</h1>
        <p className="mt-1 text-gray-500 dark:text-gray-400">
          Customize your Secure Flow Engineering experience
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Appearance */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center">
              <Palette className="w-5 h-5 mr-2 text-gray-500" />
              Appearance
            </h2>
          </div>
          <div className="p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {darkMode ? (
                  <Moon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                ) : (
                  <Sun className="w-5 h-5 text-yellow-600" />
                )}
                <div>
                  <span className="font-medium text-gray-900 dark:text-white">
                    Dark Mode
                  </span>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Toggle between light and dark theme
                  </p>
                </div>
              </div>
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 ${
                  darkMode ? 'bg-blue-600' : 'bg-gray-200'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    darkMode ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Privacy & Security */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center">
              <Shield className="w-5 h-5 mr-2 text-gray-500" />
              Privacy & Security
            </h2>
          </div>
          <div className="p-6 space-y-4">
            <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="flex items-center mb-2">
                <Shield className="w-5 h-5 text-green-600 dark:text-green-400 mr-2" />
                <span className="font-medium text-green-800 dark:text-green-300">
                  Local Storage Only
                </span>
              </div>
              <p className="text-sm text-green-700 dark:text-green-400">
                All your data is stored locally in your browser. No data is sent to external servers.
              </p>
            </div>
            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <div className="flex items-center mb-2">
                <Database className="w-5 h-5 text-blue-600 dark:text-blue-400 mr-2" />
                <span className="font-medium text-blue-800 dark:text-blue-300">
                  Data Portability
                </span>
              </div>
              <p className="text-sm text-blue-700 dark:text-blue-400">
                Export your data anytime using the Data Manager section.
              </p>
            </div>
          </div>
        </div>

        {/* Notifications */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center">
              <Bell className="w-5 h-5 mr-2 text-gray-500" />
              Notifications
            </h2>
          </div>
          <div className="p-6 space-y-4">
            <div className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Notification preferences will be available in a future update.
              </p>
            </div>
          </div>
        </div>

        {/* About */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center">
              <Info className="w-5 h-5 mr-2 text-gray-500" />
              About
            </h2>
          </div>
          <div className="p-6 space-y-4">
            <div>
              <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                Secure Flow Engineering
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                A comprehensive job management application for engineering and contracting businesses.
              </p>
              <div className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                <div className="flex justify-between">
                  <span>Version:</span>
                  <span className="font-medium">1.0.0</span>
                </div>
                <div className="flex justify-between">
                  <span>Built with:</span>
                  <span className="font-medium">React + TypeScript</span>
                </div>
                <div className="flex justify-between">
                  <span>Data Storage:</span>
                  <span className="font-medium">Local Browser Storage</span>
                </div>
              </div>
            </div>
            
            <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
              <h4 className="font-medium text-gray-900 dark:text-white mb-2">Features:</h4>
              <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                <li>• Job & Client Management</li>
                <li>• Financial Tracking & Tax Calculations</li>
                <li>• Data Export & Import</li>
                <li>• Responsive Design</li>
                <li>• Dark Mode Support</li>
                <li>• Offline Capability</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* System Information */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center">
            <Globe className="w-5 h-5 mr-2 text-gray-500" />
            System Information
          </h2>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
            <div className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <div className="font-medium text-gray-900 dark:text-white">Browser</div>
              <div className="text-gray-600 dark:text-gray-400">
                {navigator.userAgent.includes('Chrome') ? 'Chrome' :
                 navigator.userAgent.includes('Firefox') ? 'Firefox' :
                 navigator.userAgent.includes('Safari') ? 'Safari' :
                 navigator.userAgent.includes('Edge') ? 'Edge' : 'Unknown'}
              </div>
            </div>
            <div className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <div className="font-medium text-gray-900 dark:text-white">Platform</div>
              <div className="text-gray-600 dark:text-gray-400">
                {navigator.platform}
              </div>
            </div>
            <div className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <div className="font-medium text-gray-900 dark:text-white">Language</div>
              <div className="text-gray-600 dark:text-gray-400">
                {navigator.language}
              </div>
            </div>
            <div className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <div className="font-medium text-gray-900 dark:text-white">Theme</div>
              <div className="text-gray-600 dark:text-gray-400">
                {darkMode ? 'Dark' : 'Light'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}