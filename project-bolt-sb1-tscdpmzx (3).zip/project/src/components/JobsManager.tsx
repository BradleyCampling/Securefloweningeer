import React, { useState } from 'react';
import { Job, Client } from '../types';
import { 
  Plus, 
  Search, 
  Filter, 
  Edit2, 
  Trash2, 
  CheckCircle, 
  Clock, 
  AlertCircle,
  Calendar,
  DollarSign
} from 'lucide-react';
import { Modal } from './Modal';
import { JobForm } from './JobForm';
import { showToast } from './Toast';

interface JobsManagerProps {
  jobs: Job[];
  setJobs: (jobs: Job[]) => void;
  clients: Client[];
}

export function JobsManager({ jobs, setJobs, clients }: JobsManagerProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [paymentFilter, setPaymentFilter] = useState<string>('all');
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);

  const filteredJobs = jobs.filter((job) => {
    const client = clients.find(c => c.id === job.clientId);
    const searchMatch = 
      job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      client?.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    const statusMatch = statusFilter === 'all' || job.status === statusFilter;
    const paymentMatch = 
      paymentFilter === 'all' || 
      (paymentFilter === 'paid' && job.isPaid) ||
      (paymentFilter === 'unpaid' && !job.isPaid);

    return searchMatch && statusMatch && paymentMatch;
  });

  const handleAddJob = () => {
    setSelectedJob(null);
    setIsFormOpen(true);
  };

  const handleEditJob = (job: Job) => {
    setSelectedJob(job);
    setIsFormOpen(true);
  };

  const handleDeleteJob = (jobId: string) => {
    if (confirm('Are you sure you want to delete this job?')) {
      setJobs(jobs.filter(job => job.id !== jobId));
      showToast('Job deleted successfully', 'success');
    }
  };

  const handleTogglePayment = (jobId: string) => {
    setJobs(jobs.map(job => 
      job.id === jobId 
        ? { ...job, isPaid: !job.isPaid, updatedAt: new Date().toISOString() }
        : job
    ));
    showToast('Payment status updated', 'success');
  };

  const handleSaveJob = (jobData: Omit<Job, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (selectedJob) {
      // Edit existing job
      setJobs(jobs.map(job => 
        job.id === selectedJob.id 
          ? { ...jobData, id: selectedJob.id, createdAt: selectedJob.createdAt, updatedAt: new Date().toISOString() }
          : job
      ));
      showToast('Job updated successfully', 'success');
    } else {
      // Add new job
      const newJob: Job = {
        ...jobData,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      setJobs([...jobs, newJob]);
      showToast('Job created successfully', 'success');
    }
    setIsFormOpen(false);
  };

  const getStatusIcon = (job: Job) => {
    if (job.status === 'completed') {
      return job.isPaid ? 
        <CheckCircle className="w-5 h-5 text-green-500" /> :
        <AlertCircle className="w-5 h-5 text-orange-500" />;
    }
    return <Clock className="w-5 h-5 text-blue-500" />;
  };

  const getStatusBadge = (job: Job) => {
    const baseClasses = "px-3 py-1 rounded-full text-xs font-medium";
    
    switch (job.status) {
      case 'active':
        return `${baseClasses} bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300`;
      case 'completed':
        return job.isPaid
          ? `${baseClasses} bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300`
          : `${baseClasses} bg-orange-100 dark:bg-orange-900/20 text-orange-800 dark:text-orange-300`;
      case 'cancelled':
        return `${baseClasses} bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-300`;
      default:
        return `${baseClasses} bg-gray-100 dark:bg-gray-900/20 text-gray-800 dark:text-gray-300`;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Jobs Manager</h1>
          <p className="mt-1 text-gray-500 dark:text-gray-400">
            Manage your jobs and track their progress
          </p>
        </div>
        <button
          onClick={handleAddJob}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Add Job</span>
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search jobs or clients..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
          
          <select
            value={paymentFilter}
            onChange={(e) => setPaymentFilter(e.target.value)}
            className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Payments</option>
            <option value="paid">Paid</option>
            <option value="unpaid">Unpaid</option>
          </select>
        </div>
      </div>

      {/* Jobs Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredJobs.map((job) => {
          const client = clients.find(c => c.id === job.clientId);
          
          return (
            <div
              key={job.id}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow duration-200"
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">
                      {job.title}
                    </h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {client?.name || 'Unknown Client'}
                    </p>
                  </div>
                  {getStatusIcon(job)}
                </div>
                
                <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 line-clamp-2">
                  {job.description}
                </p>
                
                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Amount:</span>
                    <span className="font-medium text-gray-900 dark:text-white">
                      £{job.amount.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Hours:</span>
                    <span className="font-medium text-gray-900 dark:text-white">
                      {job.hoursWorked}h
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Rate:</span>
                    <span className="font-medium text-gray-900 dark:text-white">
                      £{job.hourlyRate}/h
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between mb-4">
                  <span className={getStatusBadge(job)}>
                    {job.status === 'completed' ? (job.isPaid ? 'Paid' : 'Unpaid') : job.status}
                  </span>
                  <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                    <Calendar className="w-4 h-4 mr-1" />
                    {new Date(job.startDate).toLocaleDateString()}
                  </div>
                </div>
                
                <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleEditJob(job)}
                      className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteJob(job.id)}
                      className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  
                  {job.status === 'completed' && (
                    <button
                      onClick={() => handleTogglePayment(job.id)}
                      className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                        job.isPaid
                          ? 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 hover:bg-green-200 dark:hover:bg-green-900/40'
                          : 'bg-orange-100 dark:bg-orange-900/20 text-orange-800 dark:text-orange-300 hover:bg-orange-200 dark:hover:bg-orange-900/40'
                      }`}
                    >
                      Mark as {job.isPaid ? 'Unpaid' : 'Paid'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredJobs.length === 0 && (
        <div className="text-center py-12">
          <div className="w-12 h-12 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center mx-auto mb-4">
            <Briefcase className="w-6 h-6 text-gray-400 dark:text-gray-500" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            No jobs found
          </h3>
          <p className="text-gray-500 dark:text-gray-400 mb-6">
            {searchTerm || statusFilter !== 'all' || paymentFilter !== 'all'
              ? "Try adjusting your filters or search term"
              : "Get started by creating your first job"
            }
          </p>
          {!searchTerm && statusFilter === 'all' && paymentFilter === 'all' && (
            <button
              onClick={handleAddJob}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg flex items-center space-x-2 mx-auto transition-colors"
            >
              <Plus className="w-5 h-5" />
              <span>Create First Job</span>
            </button>
          )}
        </div>
      )}

      {/* Job Form Modal */}
      <Modal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        title={selectedJob ? 'Edit Job' : 'Create New Job'}
      >
        <JobForm
          job={selectedJob}
          clients={clients}
          onSave={handleSaveJob}
          onCancel={() => setIsFormOpen(false)}
        />
      </Modal>
    </div>
  );
}