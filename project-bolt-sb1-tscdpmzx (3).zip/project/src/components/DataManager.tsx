import React, { useState } from 'react';
import { Job, Client } from '../types';
import { 
  Download, 
  Upload, 
  RotateCcw, 
  Database,
  FileJson,
  AlertTriangle,
  CheckCircle,
  Copy,
  HardDrive
} from 'lucide-react';
import { showToast } from './Toast';
import { initializeDemoData } from '../utils/demoData';

interface DataManagerProps {
  jobs: Job[];
  setJobs: (jobs: Job[]) => void;
  clients: Client[];
  setClients: (clients: Client[]) => void;
}

export function DataManager({ jobs, setJobs, clients, setClients }: DataManagerProps) {
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [lastBackup, setLastBackup] = useState<string | null>(
    localStorage.getItem('sfe_last_backup')
  );

  const exportData = () => {
    setIsExporting(true);
    
    try {
      const data = {
        jobs,
        clients,
        exportDate: new Date().toISOString(),
        version: '1.0'
      };

      const jsonString = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      const a = document.createElement('a');
      a.href = url;
      a.download = `secure-flow-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      
      URL.revokeObjectURL(url);
      
      const backupTime = new Date().toISOString();
      localStorage.setItem('sfe_last_backup', backupTime);
      setLastBackup(backupTime);
      
      showToast('Data exported successfully!', 'success');
    } catch (error) {
      showToast('Error exporting data', 'error');
    } finally {
      setIsExporting(false);
    }
  };

  const importData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.json')) {
      showToast('Please select a valid JSON file', 'error');
      return;
    }

    setIsImporting(true);
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const data = JSON.parse(content);

        // Validate data structure
        if (!data.jobs || !data.clients || !Array.isArray(data.jobs) || !Array.isArray(data.clients)) {
          throw new Error('Invalid data format');
        }

        // Validate job structure
        const validJob = (job: any): job is Job => {
          return job && typeof job.id === 'string' && typeof job.title === 'string' && 
                 typeof job.clientId === 'string' && typeof job.status === 'string' &&
                 typeof job.amount === 'number';
        };

        // Validate client structure
        const validClient = (client: any): client is Client => {
          return client && typeof client.id === 'string' && typeof client.name === 'string';
        };

        if (!data.jobs.every(validJob) || !data.clients.every(validClient)) {
          throw new Error('Invalid data structure');
        }

        // Import data
        setJobs(data.jobs);
        setClients(data.clients);
        
        showToast(`Successfully imported ${data.jobs.length} jobs and ${data.clients.length} clients`, 'success');
      } catch (error) {
        showToast('Error importing data. Please check file format.', 'error');
      } finally {
        setIsImporting(false);
      }
    };

    reader.readAsText(file);
    // Reset input
    event.target.value = '';
  };

  const resetToDemo = () => {
    if (!confirm('This will replace all your current data with demo data. Are you sure?')) {
      return;
    }

    const demoData = initializeDemoData();
    setJobs(demoData.jobs);
    setClients(demoData.clients);
    
    showToast('Data reset to demo data successfully!', 'success');
  };

  const clearAllData = () => {
    if (!confirm('This will permanently delete all your data. Are you sure?')) {
      return;
    }

    if (!confirm('This action cannot be undone. Click OK to proceed with deleting all data.')) {
      return;
    }

    setJobs([]);
    setClients([]);
    localStorage.removeItem('sfe_last_backup');
    setLastBackup(null);
    
    showToast('All data cleared successfully!', 'success');
  };

  const createAutoBackup = () => {
    try {
      const data = {
        jobs,
        clients,
        exportDate: new Date().toISOString(),
        version: '1.0',
        type: 'auto-backup'
      };

      localStorage.setItem('sfe_auto_backup', JSON.stringify(data));
      const backupTime = new Date().toISOString();
      localStorage.setItem('sfe_last_auto_backup', backupTime);
      
      showToast('Auto backup created successfully!', 'success');
    } catch (error) {
      showToast('Error creating auto backup', 'error');
    }
  };

  const restoreAutoBackup = () => {
    try {
      const backup = localStorage.getItem('sfe_auto_backup');
      if (!backup) {
        showToast('No auto backup found', 'warning');
        return;
      }

      const data = JSON.parse(backup);
      setJobs(data.jobs || []);
      setClients(data.clients || []);
      
      showToast('Auto backup restored successfully!', 'success');
    } catch (error) {
      showToast('Error restoring auto backup', 'error');
    }
  };

  const copyDataToClipboard = async () => {
    try {
      const data = {
        jobs,
        clients,
        exportDate: new Date().toISOString(),
        version: '1.0'
      };

      await navigator.clipboard.writeText(JSON.stringify(data, null, 2));
      showToast('Data copied to clipboard!', 'success');
    } catch (error) {
      showToast('Error copying to clipboard', 'error');
    }
  };

  const getStorageUsage = () => {
    const jobsSize = JSON.stringify(jobs).length;
    const clientsSize = JSON.stringify(clients).length;
    const totalSize = jobsSize + clientsSize;
    
    return {
      jobs: Math.round(jobsSize / 1024 * 10) / 10, // KB
      clients: Math.round(clientsSize / 1024 * 10) / 10, // KB
      total: Math.round(totalSize / 1024 * 10) / 10 // KB
    };
  };

  const storage = getStorageUsage();

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Data Manager</h1>
        <p className="mt-1 text-gray-500 dark:text-gray-400">
          Backup, restore, and manage your application data
        </p>
      </div>

      {/* Storage Usage */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
          <HardDrive className="w-5 h-5 mr-2 text-gray-500" />
          Storage Usage
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
              {jobs.length}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">Jobs ({storage.jobs} KB)</div>
          </div>
          <div className="text-center p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">
            <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">
              {clients.length}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">Clients ({storage.clients} KB)</div>
          </div>
          <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
            <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
              {storage.total}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">Total KB</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Export & Backup */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
            <Download className="w-5 h-5 mr-2 text-gray-500" />
            Export & Backup
          </h2>
          
          <div className="space-y-4">
            <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="flex items-center mb-2">
                <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400 mr-2" />
                <span className="font-medium text-green-800 dark:text-green-300">
                  Full Data Export
                </span>
              </div>
              <p className="text-sm text-green-700 dark:text-green-400 mb-3">
                Download all your jobs and clients data as a JSON file
              </p>
              <button
                onClick={exportData}
                disabled={isExporting}
                className="w-full bg-green-600 hover:bg-green-700 disabled:bg-green-400 text-white px-4 py-2 rounded-lg flex items-center justify-center space-x-2 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>{isExporting ? 'Exporting...' : 'Export Data'}</span>
              </button>
            </div>

            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <div className="flex items-center mb-2">
                <Database className="w-5 h-5 text-blue-600 dark:text-blue-400 mr-2" />
                <span className="font-medium text-blue-800 dark:text-blue-300">
                  Local Backup
                </span>
              </div>
              <p className="text-sm text-blue-700 dark:text-blue-400 mb-3">
                Create a backup in your browser's local storage
              </p>
              <button
                onClick={createAutoBackup}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center justify-center space-x-2 transition-colors"
              >
                <Database className="w-4 h-4" />
                <span>Create Local Backup</span>
              </button>
            </div>

            <div className="p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
              <div className="flex items-center mb-2">
                <Copy className="w-5 h-5 text-gray-600 dark:text-gray-400 mr-2" />
                <span className="font-medium text-gray-800 dark:text-gray-300">
                  Copy to Clipboard
                </span>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                Copy your data as JSON to the clipboard
              </p>
              <button
                onClick={copyDataToClipboard}
                className="w-full bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg flex items-center justify-center space-x-2 transition-colors"
              >
                <Copy className="w-4 h-4" />
                <span>Copy Data</span>
              </button>
            </div>

            {lastBackup && (
              <div className="text-sm text-gray-500 dark:text-gray-400">
                Last backup: {new Date(lastBackup).toLocaleString()}
              </div>
            )}
          </div>
        </div>

        {/* Import & Restore */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
            <Upload className="w-5 h-5 mr-2 text-gray-500" />
            Import & Restore
          </h2>
          
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <div className="flex items-center mb-2">
                <FileJson className="w-5 h-5 text-blue-600 dark:text-blue-400 mr-2" />
                <span className="font-medium text-blue-800 dark:text-blue-300">
                  Import from File
                </span>
              </div>
              <p className="text-sm text-blue-700 dark:text-blue-400 mb-3">
                Import jobs and clients from a JSON backup file
              </p>
              <label className="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center justify-center space-x-2 cursor-pointer transition-colors">
                <Upload className="w-4 h-4" />
                <span>{isImporting ? 'Importing...' : 'Choose File'}</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={importData}
                  className="hidden"
                  disabled={isImporting}
                />
              </label>
            </div>

            <div className="p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">
              <div className="flex items-center mb-2">
                <Database className="w-5 h-5 text-emerald-600 dark:text-emerald-400 mr-2" />
                <span className="font-medium text-emerald-800 dark:text-emerald-300">
                  Restore Local Backup
                </span>
              </div>
              <p className="text-sm text-emerald-700 dark:text-emerald-400 mb-3">
                Restore from your browser's local backup
              </p>
              <button
                onClick={restoreAutoBackup}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg flex items-center justify-center space-x-2 transition-colors"
              >
                <Database className="w-4 h-4" />
                <span>Restore Backup</span>
              </button>
            </div>

            <div className="p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
              <div className="flex items-center mb-2">
                <RotateCcw className="w-5 h-5 text-orange-600 dark:text-orange-400 mr-2" />
                <span className="font-medium text-orange-800 dark:text-orange-300">
                  Reset to Demo Data
                </span>
              </div>
              <p className="text-sm text-orange-700 dark:text-orange-400 mb-3">
                Replace all data with sample demo data
              </p>
              <button
                onClick={resetToDemo}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg flex items-center justify-center space-x-2 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Reset to Demo</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-red-200 dark:border-red-800">
        <div className="p-6 border-b border-red-200 dark:border-red-800">
          <h2 className="text-xl font-semibold text-red-900 dark:text-red-300 flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2" />
            Danger Zone
          </h2>
        </div>
        <div className="p-6">
          <div className="p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
            <div className="flex items-center mb-2">
              <AlertTriangle className="w-5 h-5 text-red-600 dark:text-red-400 mr-2" />
              <span className="font-medium text-red-800 dark:text-red-300">
                Clear All Data
              </span>
            </div>
            <p className="text-sm text-red-700 dark:text-red-400 mb-3">
              This will permanently delete all jobs and clients. This action cannot be undone.
            </p>
            <button
              onClick={clearAllData}
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
            >
              <AlertTriangle className="w-4 h-4" />
              <span>Clear All Data</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}