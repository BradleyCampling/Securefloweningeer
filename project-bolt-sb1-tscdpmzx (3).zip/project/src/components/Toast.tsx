import React, { useState, useEffect } from 'react';
import { CheckCircle, AlertCircle, X, Info, AlertTriangle } from 'lucide-react';

type ToastType = 'success' | 'error' | 'warning' | 'info';

interface Toast {
  id: string;
  message: string;
  type: ToastType;
  duration?: number;
}

let toastId = 0;
const toastListeners = new Set<(toasts: Toast[]) => void>();
let toasts: Toast[] = [];

export function showToast(message: string, type: ToastType = 'info', duration = 4000) {
  const toast: Toast = {
    id: (++toastId).toString(),
    message,
    type,
    duration,
  };

  toasts = [...toasts, toast];
  toastListeners.forEach(listener => listener(toasts));

  if (duration > 0) {
    setTimeout(() => {
      toasts = toasts.filter(t => t.id !== toast.id);
      toastListeners.forEach(listener => listener(toasts));
    }, duration);
  }
}

export function dismissToast(id: string) {
  toasts = toasts.filter(t => t.id !== id);
  toastListeners.forEach(listener => listener(toasts));
}

export function ToastContainer() {
  const [toastList, setToastList] = useState<Toast[]>([]);

  useEffect(() => {
    toastListeners.add(setToastList);
    return () => {
      toastListeners.delete(setToastList);
    };
  }, []);

  const getToastIcon = (type: ToastType) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-5 h-5" />;
      case 'error':
        return <AlertCircle className="w-5 h-5" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5" />;
      case 'info':
        return <Info className="w-5 h-5" />;
    }
  };

  const getToastStyles = (type: ToastType) => {
    const base = "flex items-center p-4 mb-3 rounded-lg shadow-lg border backdrop-blur-sm transition-colors duration-200";
    switch (type) {
      case 'success':
        return `${base} bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800 text-green-800 dark:text-green-300`;
      case 'error':
        return `${base} bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800 text-red-800 dark:text-red-300`;
      case 'warning':
        return `${base} bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800 text-yellow-800 dark:text-yellow-300`;
      case 'info':
        return `${base} bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-300`;
    }
  };

  if (toastList.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-50 w-96 max-w-sm">
      {toastList.map((toast) => (
        <div
          key={toast.id}
          className={`${getToastStyles(toast.type)} animate-in slide-in-from-right-full duration-300`}
        >
          <div className="flex items-center">
            {getToastIcon(toast.type)}
            <span className="ml-3 text-sm font-medium flex-1">{toast.message}</span>
            <button
              onClick={() => dismissToast(toast.id)}
              className="ml-3 p-1 hover:bg-black/10 dark:hover:bg-white/10 rounded-full transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}