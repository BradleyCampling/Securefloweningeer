import React from 'react';
import { Job, Client } from '../types';
import { 
  Briefcase, 
  Users, 
  DollarSign, 
  Clock,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Calendar
} from 'lucide-react';

interface DashboardProps {
  jobs: Job[];
  clients: Client[];
}

export function Dashboard({ jobs, clients }: DashboardProps) {
  const activeJobs = jobs.filter(job => job.status === 'active');
  const completedJobs = jobs.filter(job => job.status === 'completed');
  const unpaidJobs = jobs.filter(job => job.status === 'completed' && !job.isPaid);
  
  const totalEarned = completedJobs
    .filter(job => job.isPaid)
    .reduce((sum, job) => sum + job.amount, 0);
  
  const totalUnpaid = unpaidJobs.reduce((sum, job) => sum + job.amount, 0);

  const recentJobs = [...jobs]
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 5);

  const stats = [
    {
      title: 'Active Jobs',
      value: activeJobs.length.toString(),
      icon: Briefcase,
      color: 'text-blue-600 dark:text-blue-400',
      bgColor: 'bg-blue-100 dark:bg-blue-900/20',
    },
    {
      title: 'Total Clients',
      value: clients.length.toString(),
      icon: Users,
      color: 'text-emerald-600 dark:text-emerald-400',
      bgColor: 'bg-emerald-100 dark:bg-emerald-900/20',
    },
    {
      title: 'Total Earned',
      value: `£${totalEarned.toLocaleString()}`,
      icon: DollarSign,
      color: 'text-green-600 dark:text-green-400',
      bgColor: 'bg-green-100 dark:bg-green-900/20',
    },
    {
      title: 'Outstanding',
      value: `£${totalUnpaid.toLocaleString()}`,
      icon: AlertCircle,
      color: 'text-orange-600 dark:text-orange-400',
      bgColor: 'bg-orange-100 dark:bg-orange-900/20',
    },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
        <p className="mt-1 text-gray-500 dark:text-gray-400">
          Welcome back! Here's what's happening with your business.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.title}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition-shadow duration-200"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">
                    {stat.title}
                  </p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                    {stat.value}
                  </p>
                </div>
                <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                  <Icon className={`w-6 h-6 ${stat.color}`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Jobs */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center">
              <Clock className="w-5 h-5 mr-2 text-gray-500" />
              Recent Jobs
            </h2>
          </div>
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {recentJobs.length === 0 ? (
              <div className="p-6 text-center text-gray-500 dark:text-gray-400">
                No jobs found
              </div>
            ) : (
              recentJobs.map((job) => (
                <div key={job.id} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900 dark:text-white">
                        {job.title}
                      </h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                        {clients.find(c => c.id === job.clientId)?.name}
                      </p>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className="text-sm font-medium text-gray-900 dark:text-white">
                        £{job.amount.toLocaleString()}
                      </span>
                      {job.status === 'completed' ? (
                        job.isPaid ? (
                          <CheckCircle className="w-5 h-5 text-green-500" />
                        ) : (
                          <AlertCircle className="w-5 h-5 text-orange-500" />
                        )
                      ) : (
                        <Clock className="w-5 h-5 text-blue-500" />
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-gray-500" />
              Quick Stats
            </h2>
          </div>
          <div className="p-6 space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600 dark:text-gray-400">Completion Rate</span>
              <span className="font-semibold text-gray-900 dark:text-white">
                {jobs.length > 0 ? Math.round((completedJobs.length / jobs.length) * 100) : 0}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600 dark:text-gray-400">Payment Rate</span>
              <span className="font-semibold text-gray-900 dark:text-white">
                {completedJobs.length > 0 
                  ? Math.round((completedJobs.filter(j => j.isPaid).length / completedJobs.length) * 100)
                  : 0}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600 dark:text-gray-400">Avg Job Value</span>
              <span className="font-semibold text-gray-900 dark:text-white">
                £{jobs.length > 0 ? Math.round(jobs.reduce((sum, job) => sum + job.amount, 0) / jobs.length) : 0}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600 dark:text-gray-400">This Month</span>
              <span className="font-semibold text-gray-900 dark:text-white">
                {jobs.filter(job => {
                  const jobDate = new Date(job.createdAt);
                  const now = new Date();
                  return jobDate.getMonth() === now.getMonth() && 
                         jobDate.getFullYear() === now.getFullYear();
                }).length} jobs
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}