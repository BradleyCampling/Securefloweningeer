import React, { useState, useMemo } from 'react';
import { Job } from '../types';
import { 
  Calculator, 
  TrendingUp, 
  DollarSign, 
  Calendar,
  Download,
  PieChart,
  BarChart3,
  FileText
} from 'lucide-react';

interface FinancialToolsProps {
  jobs: Job[];
}

interface TaxCalculation {
  grossIncome: number;
  incomeTax: number;
  nationalInsurance: number;
  netIncome: number;
  taxRate: number;
  niRate: number;
}

interface MonthlyBreakdown {
  month: string;
  earned: number;
  unpaid: number;
  jobsCompleted: number;
}

export function FinancialTools({ jobs }: FinancialToolsProps) {
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [showTaxCalculator, setShowTaxCalculator] = useState(false);

  const years = useMemo(() => {
    const jobYears = jobs.map(job => new Date(job.createdAt).getFullYear());
    return Array.from(new Set([...jobYears, new Date().getFullYear()])).sort((a, b) => b - a);
  }, [jobs]);

  const yearlyData = useMemo(() => {
    const yearJobs = jobs.filter(job => 
      new Date(job.createdAt).getFullYear() === selectedYear
    );

    const completedJobs = yearJobs.filter(job => job.status === 'completed');
    const paidJobs = completedJobs.filter(job => job.isPaid);
    const unpaidJobs = completedJobs.filter(job => !job.isPaid);

    const totalEarned = paidJobs.reduce((sum, job) => sum + job.amount, 0);
    const totalUnpaid = unpaidJobs.reduce((sum, job) => sum + job.amount, 0);
    const totalRevenue = totalEarned + totalUnpaid;

    // Monthly breakdown
    const monthlyBreakdown: MonthlyBreakdown[] = [];
    for (let month = 0; month < 12; month++) {
      const monthJobs = completedJobs.filter(job => 
        new Date(job.completedDate || job.createdAt).getMonth() === month
      );
      
      const monthEarned = monthJobs.filter(job => job.isPaid)
        .reduce((sum, job) => sum + job.amount, 0);
      const monthUnpaid = monthJobs.filter(job => !job.isPaid)
        .reduce((sum, job) => sum + job.amount, 0);

      monthlyBreakdown.push({
        month: new Date(2024, month, 1).toLocaleString('default', { month: 'long' }),
        earned: monthEarned,
        unpaid: monthUnpaid,
        jobsCompleted: monthJobs.length,
      });
    }

    return {
      totalJobs: yearJobs.length,
      activeJobs: yearJobs.filter(job => job.status === 'active').length,
      completedJobs: completedJobs.length,
      totalEarned,
      totalUnpaid,
      totalRevenue,
      averageJobValue: completedJobs.length > 0 ? totalRevenue / completedJobs.length : 0,
      monthlyBreakdown,
    };
  }, [jobs, selectedYear]);

  const calculateTax = (income: number): TaxCalculation => {
    // UK Tax rates for 2024/25
    const personalAllowance = 12570;
    const basicRateThreshold = 50270;
    const higherRateThreshold = 125140;

    // Income Tax
    let incomeTax = 0;
    let taxableIncome = Math.max(0, income - personalAllowance);

    if (taxableIncome > 0) {
      if (taxableIncome <= basicRateThreshold - personalAllowance) {
        incomeTax = taxableIncome * 0.2; // 20% basic rate
      } else if (taxableIncome <= higherRateThreshold - personalAllowance) {
        incomeTax = (basicRateThreshold - personalAllowance) * 0.2 + 
                   (taxableIncome - (basicRateThreshold - personalAllowance)) * 0.4; // 40% higher rate
      } else {
        incomeTax = (basicRateThreshold - personalAllowance) * 0.2 + 
                   (higherRateThreshold - basicRateThreshold) * 0.4 +
                   (taxableIncome - (higherRateThreshold - personalAllowance)) * 0.45; // 45% additional rate
      }
    }

    // National Insurance (Class 2 & 4 for self-employed)
    let nationalInsurance = 0;
    const niThreshold = 12570;
    const niUpperThreshold = 50270;

    if (income > niThreshold) {
      const niableIncome = Math.min(income, niUpperThreshold) - niThreshold;
      nationalInsurance = niableIncome * 0.09; // 9% on earnings between thresholds
      
      if (income > niUpperThreshold) {
        nationalInsurance += (income - niUpperThreshold) * 0.02; // 2% on earnings above upper threshold
      }
    }

    // Class 2 NI (£3.45 per week if profit over £6,515)
    if (income > 6515) {
      nationalInsurance += 3.45 * 52; // £179.40 per year
    }

    const netIncome = income - incomeTax - nationalInsurance;

    return {
      grossIncome: income,
      incomeTax,
      nationalInsurance,
      netIncome,
      taxRate: income > 0 ? (incomeTax / income) * 100 : 0,
      niRate: income > 0 ? (nationalInsurance / income) * 100 : 0,
    };
  };

  const taxCalculation = calculateTax(yearlyData.totalEarned);

  const exportToCSV = () => {
    const csvContent = [
      ['Month', 'Jobs Completed', 'Earned (£)', 'Unpaid (£)', 'Total (£)'],
      ...yearlyData.monthlyBreakdown.map(month => [
        month.month,
        month.jobsCompleted.toString(),
        month.earned.toFixed(2),
        month.unpaid.toFixed(2),
        (month.earned + month.unpaid).toFixed(2)
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `financial-report-${selectedYear}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const maxMonthlyEarnings = Math.max(...yearlyData.monthlyBreakdown.map(m => m.earned + m.unpaid));

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Financial Tools</h1>
          <p className="mt-1 text-gray-500 dark:text-gray-400">
            Track your income, expenses, and tax obligations
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(parseInt(e.target.value))}
            className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
          >
            {years.map(year => (
              <option key={year} value={year}>{year}</option>
            ))}
          </select>
          
          <button
            onClick={exportToCSV}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">
                £{yearlyData.totalRevenue.toLocaleString()}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-blue-100 dark:bg-blue-900/20">
              <DollarSign className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Paid Income</p>
              <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                £{yearlyData.totalEarned.toLocaleString()}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-green-100 dark:bg-green-900/20">
              <TrendingUp className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Outstanding</p>
              <p className="text-2xl font-bold text-orange-600 dark:text-orange-400">
                £{yearlyData.totalUnpaid.toLocaleString()}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-orange-100 dark:bg-orange-900/20">
              <Calendar className="w-6 h-6 text-orange-600 dark:text-orange-400" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Net Income</p>
              <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                £{Math.round(taxCalculation.netIncome).toLocaleString()}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-purple-100 dark:bg-purple-900/20">
              <Calculator className="w-6 h-6 text-purple-600 dark:text-purple-400" />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Tax Calculator */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center">
              <Calculator className="w-5 h-5 mr-2 text-gray-500" />
              UK Tax Calculation ({selectedYear})
            </h2>
          </div>
          <div className="p-6 space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600 dark:text-gray-400">Gross Income:</span>
              <span className="font-semibold text-gray-900 dark:text-white">
                £{taxCalculation.grossIncome.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600 dark:text-gray-400">Income Tax:</span>
              <span className="font-semibold text-red-600 dark:text-red-400">
                -£{Math.round(taxCalculation.incomeTax).toLocaleString()} 
                ({taxCalculation.taxRate.toFixed(1)}%)
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600 dark:text-gray-400">National Insurance:</span>
              <span className="font-semibold text-red-600 dark:text-red-400">
                -£{Math.round(taxCalculation.nationalInsurance).toLocaleString()} 
                ({taxCalculation.niRate.toFixed(1)}%)
              </span>
            </div>
            <hr className="border-gray-200 dark:border-gray-700" />
            <div className="flex justify-between items-center">
              <span className="text-lg font-medium text-gray-900 dark:text-white">Net Income:</span>
              <span className="text-lg font-bold text-green-600 dark:text-green-400">
                £{Math.round(taxCalculation.netIncome).toLocaleString()}
              </span>
            </div>
            <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <p className="text-sm text-blue-800 dark:text-blue-300">
                <strong>Note:</strong> This is an estimate based on 2024/25 tax rates. 
                Consult a tax professional for accurate calculations.
              </p>
            </div>
          </div>
        </div>

        {/* Monthly Chart */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center">
              <BarChart3 className="w-5 h-5 mr-2 text-gray-500" />
              Monthly Earnings ({selectedYear})
            </h2>
          </div>
          <div className="p-6">
            <div className="space-y-3">
              {yearlyData.monthlyBreakdown.filter(month => month.earned > 0 || month.unpaid > 0).map((month) => {
                const total = month.earned + month.unpaid;
                const earnedPercentage = maxMonthlyEarnings > 0 ? (month.earned / maxMonthlyEarnings) * 100 : 0;
                const unpaidPercentage = maxMonthlyEarnings > 0 ? (month.unpaid / maxMonthlyEarnings) * 100 : 0;

                return (
                  <div key={month.month} className="space-y-1">
                    <div className="flex justify-between items-center text-sm">
                      <span className="font-medium text-gray-700 dark:text-gray-300">
                        {month.month}
                      </span>
                      <span className="text-gray-500 dark:text-gray-400">
                        £{total.toLocaleString()} ({month.jobsCompleted} jobs)
                      </span>
                    </div>
                    <div className="relative h-6 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                      <div
                        className="absolute left-0 top-0 h-full bg-green-500 dark:bg-green-400"
                        style={{ width: `${earnedPercentage}%` }}
                      />
                      <div
                        className="absolute top-0 h-full bg-orange-500 dark:bg-orange-400"
                        style={{ 
                          left: `${earnedPercentage}%`,
                          width: `${unpaidPercentage}%` 
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-4 flex items-center justify-center space-x-6 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full" />
                <span className="text-gray-600 dark:text-gray-400">Paid</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-orange-500 rounded-full" />
                <span className="text-gray-600 dark:text-gray-400">Unpaid</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Monthly Breakdown */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center">
            <FileText className="w-5 h-5 mr-2 text-gray-500" />
            Monthly Breakdown ({selectedYear})
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-700/50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Month
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Jobs
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Earned
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Outstanding
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Total
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {yearlyData.monthlyBreakdown.map((month, index) => (
                <tr key={month.month} className={index % 2 === 0 ? 'bg-white dark:bg-gray-800' : 'bg-gray-50 dark:bg-gray-800/50'}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                    {month.month}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {month.jobsCompleted}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600 dark:text-green-400">
                    £{month.earned.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-orange-600 dark:text-orange-400">
                    £{month.unpaid.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                    £{(month.earned + month.unpaid).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-gray-50 dark:bg-gray-700/50">
              <tr>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900 dark:text-white">
                  Total
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900 dark:text-white">
                  {yearlyData.completedJobs}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-green-600 dark:text-green-400">
                  £{yearlyData.totalEarned.toLocaleString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-orange-600 dark:text-orange-400">
                  £{yearlyData.totalUnpaid.toLocaleString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900 dark:text-white">
                  £{yearlyData.totalRevenue.toLocaleString()}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
}