export interface Job {
  id: string;
  clientId: string;
  title: string;
  description: string;
  status: 'active' | 'completed' | 'cancelled';
  isPaid: boolean;
  amount: number;
  hourlyRate: number;
  hoursWorked: number;
  startDate: string;
  completedDate?: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  company?: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface FinancialSummary {
  totalEarned: number;
  totalUnpaid: number;
  monthlyBreakdown: MonthlyBreakdown[];
  taxCalculation: TaxCalculation;
}

export interface MonthlyBreakdown {
  month: string;
  earned: number;
  unpaid: number;
  jobsCompleted: number;
}

export interface TaxCalculation {
  grossIncome: number;
  incomeTax: number;
  nationalInsurance: number;
  netIncome: number;
  taxRate: number;
  niRate: number;
}